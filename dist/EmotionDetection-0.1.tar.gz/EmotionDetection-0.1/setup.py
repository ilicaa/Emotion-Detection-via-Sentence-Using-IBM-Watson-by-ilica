from setuptools import setup

setup(
    name='EmotionDetection',
    version='0.1',
    packages=['emotion_detection'],
    install_requires=[
        'requests',
    ],
)
